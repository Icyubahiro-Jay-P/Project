<?php
    include("connect.php");
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- <link rel="stylesheet" href="style.css"> -->
    <link rel="stylesheet" href="icons/bootstrap-icons.css">
    <link rel="stylesheet" href="icons/bootstrap-icons.min.css">
</head>
<body>
    <style>
        :root{
            --primary-clr:#194857;
            --bg-clr:#e2e4e5;
            --white-bg:#fff;
            --dark-text-clr:#363b46;
            --light-text-clr:#fff;
            --hover-clr:#306057;
            --gray:#cacaca;
        }
        @font-face {
            font-family: "Poppins";
            src: url("Fonts/Poppins/Poppins-Regular.ttf");
        }
        @font-face {
            font-family: "Poppins-Medium";
            src: url("Fonts/Poppins/Poppins-Medium.ttf");
        }
    *{
        margin: 0;
        padding: 0;
        border: none;
        outline: none;
        box-sizing: border-box;
        font-family: "Poppins", sans-serif;
    }
    body{
        display: flex;
        transition: 0.5s ease;
    }
    .sidebar{
        position: sticky;
        top: 0;
        left: 0;
        bottom: 0;
        width: 100px;
        height: 100vh;
        padding: 0 1.4rem;
        color: #fff;
        overflow: hidden;
        transition: all 0.5s ease-in-out;
        background: var(--primary-clr);
    }
    .sidebar:hover{
        width: 320px;
        transition: 0.5s all;
    }
    .logo{
        height: 80px;
        padding: 16px;
    }
    .menu{
        height: 100%;
        position: relative;
        list-style: none;
        padding: 0;
    }
    ul li.active a{
    color: var(--light-text-clr);
    /* background-color: var(--primary-clr); */
}
    .menu li {
        padding: 0.7rem;
        margin: 2px 0;
        border-radius: 8px;
        transition: all 0.5s ease-in-out;
    }
    .menu li:hover,
    .active{
        background: var(--hover-clr);
    }
    .menu a {
        color: #fff;
        font-size: 14px;
        text-decoration: none;
        display: flex;
        align-items: center;
        gap: 1rem;
    }
    .menu a span{
        overflow: hidden;
    }
    .menu a i{
        font-size: 1.2rem;
        transform: translateX(4px);
    }
    .logout{
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
    }
    /* ********** body stuff *********** */
    .main--content{
        position: relative;
        background: var(--white-bg);
        width: 100%;
        padding: 1rem;
    }
    .header--wrapper img{
        width: 50px;
        height: 50px;
        cursor: pointer;
        border-radius: 50%;
    }
    .header--wrapper{
        display: flex;
        justify-content: space-between;
        align-items: center;
        flex-wrap: wrap;
        background: var(--bg-clr);
        border-radius: 10px;
        padding: 10px 2rem;
        margin-bottom: 1rem;
    }
    .header--title{
        color: var(--primary-clr);
    }
    .user--info{
        display: flex;
        align-items: center;
        gap: 1rem;
    }
    .search--box{
        background: var(--gray);
        border-radius: 15px;
        color: rgba(133, 99, 186, 255);
        display: flex;
        align-items: center;
        gap: 5px;
        padding: 4px 10px;
        width: 40px;
        overflow: hidden;
    }
    .search--box input{
        background: transparent;
        padding: 10px;
        font-size: 16px;
    }
    .search--box i{
        font-size: 1.2rem;
        color: var(--primary-clr);
        cursor: pointer;
        transition: all 0.5s ease-out;
    }
    .search--box i:hover{
        transform: scale(1.2);
    }
    /* ************ table stuff ********** */
    .tabular--wrapper{
        background: var(--bg-clr);
        margin-top: 1rem;
        border-radius: 10px;
        padding: 2rem;
    }
    .table-container{
        width: 100%;
    }
    table{
        width: 100%;
        border-collapse: collapse;
    }
    thead{
        background: var(--primary-clr);
        color: var(--white-bg);
    }
    th{
        padding: 15px;
        text-align: left;
    }
    tbody{
        background: #f2f2f2;
    }
    td{
        padding: 15px;
        font-size: 14px;
        color: var(--dark-text-clr);
    }
    tr:nth-child(even) {
        background: var(--gray);
    }
    tfoot{
        background: var(--primary-clr);
        font-weight: bold;
        color: var(--dark-text-clr);
    }
    tfoot td{
        padding: 15px;
        color: #fff;
    }
    .table-container button{
        color: green;
        background: none;
        cursor: pointer;
    }
    </style>
    <div class="sidebar">
        <div class="logo"></div>
        <ul class="menu">
            <li class="menu-item active">
                <a href="#">
                    <i class="bi bi-house-door-fill"></i>
                    <span>Ahabanza</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="#">
                    <i class="bi bi-person-circle"></i>
                    <span>Umwirondoro</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="#">
                    <i class="bi bi-plus-circle"></i>
                    <span>Ongeramo&nbsp;Umukiriya</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="#">
                    <i class="bi bi-plus-circle-fill"></i>
                    <span>Ongeramo&nbsp;Igicuruzwa</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="#">
                    <i class="bi bi-people"></i>
                    <span>Umukozi&nbsp;mushya</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="#">
                    <i class="bi bi-gear-fill"></i>
                    <span>Settings</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="#">
                    <i class="bi bi-box-arrow-left"></i>
                    <span>Sohoka</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="container main--content">
        <div class="header--wrapper">
            <div class="header--title">
                <h2>Best Decor</h2>
                <span>Ahabanza</span>
            </div>
            <div class="user--info">
                <div class="search--box">
                <i class="bi bi-search"></i>
                <input type="text" placeholder="Search">
                </div>
                <img src="./Images/Background-Pic.png" alt="">
            </div>
        </div>
        <div class="tabular--wrapper">
            <h3 class="main--title">Finance Data</h3>
            <div class="table-container">
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Transaction Type</th>
                            <th>Description</th>
                            <th>Amount</th>
                            <th>Category</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                        <tbody>
                            <tr>
                                <td>11-06-2024</td>
                                <td>Expenses</td>
                                <td>Office Supplies</td>
                                <td>$250</td>
                                <td>Office Expenses</td>
                                <td>Pending</td>
                                <td><button><i class="bi bi-pencil"></i>Edit</button></td>
                            </tr>
                            <tr>
                                <td>12-06-2024</td>
                                <td>Income</td>
                                <td>Home Supplies</td>
                                <td>$350</td>
                                <td>Office Income</td>
                                <td>Pending</td>
                                <td><button><i class="bi bi-pencil"></i>Edit</button></td>
                            </tr>
                            <tr>
                                <td>11-06-2024</td>
                                <td>Expenses</td>
                                <td>Office Supplies</td>
                                <td>$250</td>
                                <td>Office Expenses</td>
                                <td>Pending</td>
                                <td><button><i class="bi bi-pencil"></i>Edit</button></td>
                            </tr>
                            <tr>
                                <td>11-06-2024</td>
                                <td>Expenses</td>
                                <td>Office Supplies</td>
                                <td>$250</td>
                                <td>Office Expenses</td>
                                <td>Pending</td>
                                <td><button><i class="bi bi-pencil"></i>Edit</button></td>
                            </tr>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="7">Total: $1,000</td>
                            </tr>
                        </tfoot>
                </table>
            </div>
        </div>
    </div>
    <script src="Icons/bootstrap-icons.json"></script>
    <script>
        const container = document.querySelector(".container");
        const linkItem = document.querySelectorAll(".menu-item");
        const searchBox = document.querySelector(".search--box");

        searchBox.addEventListener("click", ()=>{
            searchBox.style.width = `270px`;
            searchBox.style.transition = `0.5s ease-in`;
        })
        for(let i = 0;i < linkItem.length; i++){
        if(!linkItem[i].classList.contains("dark-mode")){
        linkItem[i].addEventListener("click", () =>{
        linkItem.forEach((linkItem) => {
            linkItem.classList.remove("active")
        })
        linkItem[i].classList.add("active");
        });
    }
}
    </script>
</body>
</html>