<?php
include("connect.php");
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Decor:Sign Up</title>
</head>
<body>
<style>
        @font-face {
            font-family: "Poppins";
            src: url("Fonts/Poppins/Poppins-Regular.ttf");
        }
        @font-face {
            font-family: "Poppins-Medium";
            src: url("Fonts/Poppins/Poppins-Medium.ttf");
        }
        body{
            font-family: "Poppins";
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            background: #ddd;
        }
        .input-group{
            margin: 20px 0;
            position: relative;
        }
        .input-group input,
        .input-group input[type="date"]{
            font-family: "Poppins";
            width: 300px;
            height: 50px;
            color: #000;
            font-size: 18px;
            box-shadow: 0 0 10px #ccc;
            padding: 0 15px;
            border: 1.5px solid #bbb;
            background: #fff;
            outline: none;
            border-radius: 5px;
        }
        .input-group input::placeholder{
            font-family: "Poppins";
            font-size: 17px;
        }
        .input-group input:focus~label,
        .input-group input:valid~label{
            top: 0;
            font-size: 14px;
            background: #000;
        }
        #showPassword{
            cursor: pointer;
        }
        input[type="submit"]{
            transform: translateX(-20px);
            width: 250px;
            height: 44px;
            color: #03f;
            border-radius: 5px;
            border: 1.7px solid #05f;
            font-family: "Poppins-Medium";
            font-size: 18px;
            box-shadow: 0 0 10px #ccc;
            display: flex;
            position: relative;
            justify-content: center;
            text-align: center;
            margin: auto;
            transition: .5s ease-in-out;
        }
        input[type="submit"]:hover{
            border: none;
            background: #03f;
            color: #fff;
        }
        a{
            text-decoration: none;
            color: #02f;
            font-size: 17px;
        }
        .error{
            margin-top: 10px;
            transform: translateY(-770px);
            border-radius: 5px;
            color: #fff;
            align-items: center;
            text-align: center;
            background: #e12;
            animation: popUpError .5s ease-in;
            width: 200px;
            height: 50px;
            font-size: 18px;
            transition: .5s ease-in;
        }
        .success{
            margin-top: 10px;
            transform: translateY(-540px);
            border-radius: 5px;
            color: #fff;
            align-items: center;
            text-align: center;
            background: #0a0;
            animation: popUpSuccess .5s ease-in;
            width: 200px;
            height: 50px;
            font-size: 18px;
            transition: .5s ease-in;

        }
        .error p{
            transform: translateY(-7px);
        }
        @keyframes popUpError {
            0%{
                opacity: 0.5;
                transform: translateY(-750px);
            }
            100%{
                opacity: 1;
                transform: translateY(-770px);
            }
        }
    </style>
    <form id="login-form" method="post">
        <h1>Best Decor</h1>
        <h3>Sign Up</h3>
        <div class="input-group">
            <input type="email" id="inputBox" name="email" placeholder="Email" required>
        </div>
        <div class="input-group">
            <input type="number" id="inputBox" name="phone_number" placeholder="Phone number" required>
        </div>
        <div class="input-group">
            <input type="text" id="inputBox" name="first_name" placeholder="First name" required>
        </div>
        <div class="input-group">
            <input type="text" id="inputBox" name="last_name" placeholder="Last name" required>
        </div>
        <div class="input-group">
            <input type="password" id="inputBox" name="password" placeholder="Password" required>
            <span id="showPassword">Show</span>
        </div>
        <div class="input-group">
            <input type="password" id="inputBox" name="confirmedPassword" placeholder="Confirm Password" required>
            <span id="showPassword">Show</span>
        </div>
        <div class="input-group">
            <label>Date of Birth:</label><br>
            <input type="date" name="dateOfBirth"><br>
        </div>
        <input type="submit" name="submit" value="Sign Up"><br
        <p>Already have an account?&nbsp;<a href="index.php">Log in</a></p>
     </form>
     <h4>&copy;Copyright 2024</h4>
     <script>
            const showPasswordElements = document.querySelectorAll('#showPassword');
            showPasswordElements.forEach((showPassword, index) => {
                const passwordInput = document.querySelectorAll('input[type="password"]')[index];
                showPassword.addEventListener("click", () => {
                    if (showPassword.textContent === "Show") {
                        passwordInput.setAttribute("type", "text");
                        showPassword.textContent = "Hide";
                    } else {
                        passwordInput.setAttribute("type", "password");
                        showPassword.textContent = "Show";
                    }
                });
            });
    </script>
</body>
</html>
<?php
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        
        $email = filter_input(INPUT_POST, "email", FILTER_SANITIZE_EMAIL);
        $phone_number = filter_input(INPUT_POST, "phone_number", FILTER_SANITIZE_NUMBER_INT);
        $first_name = filter_input(INPUT_POST, "first_name", FILTER_SANITIZE_SPECIAL_CHARS);
        $last_name = filter_input(INPUT_POST, "last_name", FILTER_SANITIZE_SPECIAL_CHARS);
        $password = filter_input(INPUT_POST, "password", FILTER_SANITIZE_SPECIAL_CHARS);
        $confirmedPassword = filter_input(INPUT_POST, "confirmedPassword", FILTER_SANITIZE_SPECIAL_CHARS);
        $dateOfBirth = filter_input(INPUT_POST, "dateOfBirth", FILTER_SANITIZE_SPECIAL_CHARS);
        // session to store email, password, first name, last name, phone number
        if(empty($email)){
            echo "Email is required";
        }
        elseif(empty($phone_number)){
            echo "Phone number is required";
        }
        elseif(empty($first_name)){
            echo "First name is required";
        }
        elseif(empty($last_name)){
            echo "Last name is required";
        }
        elseif(empty($password)){
            echo "Password is required";
        }
        elseif(empty($confirmedPassword)){
            echo "Confirmed password is required";
        }
        elseif(empty($dateOfBirth)){
            echo "Date of Birth is required";
        }
        else{
            if($password == $confirmedPassword){
                try{
                    $hash = md5($password);
                    $query = "INSERT INTO users (email, phone_number, first_name, last_name, password, date_of_birth)
                        VALUES ('$email', '$phone_number', '$first_name', '$last_name', '$hash', '$dateOfBirth')";
                mysqli_query($conn, $query);
                echo "<div class='success'><p>Registered successfully</p></div>";
                header("Location: logged_in.php");
            }
            catch(mysqli_sql_exception){
                echo"<div class='error'><p>Email already exists</p></div>";
            }
            // $_SESSION["first_name"] = mysqli_query($conn, $first_name);
            // $_SESSION["last_name"] = mysqli_query($conn, $last_name);
            // $_SESSION["email"] = mysqli_query($conn, $email);
        }
        else{
            echo "Password don't match";
        }
    }
}
    mysqli_close($conn);
?>