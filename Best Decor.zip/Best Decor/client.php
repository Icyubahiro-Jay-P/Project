<?php
    include("connect.php");
    session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<style>
        @font-face {
            font-family: "Poppins";
            src: url("Fonts/Poppins/Poppins-light.ttf");
        }
        body{
            font-family: "Poppins";
        }
        input{
            font-family: "Poppins";
        }
    </style>
<body>
    <header>
        <h1>Best Decor</h1>
        <h2>Andika umukiriya mushya</h2>
    </header>
</body>
</html>