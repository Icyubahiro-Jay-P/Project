<?php
include("connect.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Decor: Log In</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Best Decor</h1>
    <h3>Log in</h3>
    <form method="post">
    <div class="input-group">
        <input type="email" name="email" id="inputBox" placeholder="Email" required>
    </div>
    <div class="input-group">
        <input type="password" name="password" placeholder="Password" required>
        <span id="showPassword">Show</span>
    </div>
    <div class="input-group">
        <input type="submit" name="submit" value="Log in">
    </div>
    <p>No account? <a href="signup.php">Sign up</a></p>
    </form>
    <h4>&copy;Copyright 2024</h4>
    <script>
        const showPassword = document.getElementById('showPassword');
        const passwordInput = document.querySelector('input[name = "password"]');
        showPassword.addEventListener("click", ()=> {
            if (showPassword.textContent === "Show") {
                passwordInput.setAttribute("type", "text");
                showPassword.textContent = "Hide";
            } else {
                passwordInput.setAttribute("type", "password");
                showPassword.textContent = "Show";
            }
        })
     </script>
</body>
</html>
<?php
    if (isset($_POST['submit'])){
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $password = mysqli_real_escape_string($conn, $_POST['password']);

        $hash = md5($password);


        $verify_email = mysqli_query($conn, "SELECT * FROM users where email='{$email}'");
        if (mysqli_num_rows($verify_email) > 0 ){
            $verify_password = mysqli_fetch_assoc($verify_email);
                if ($hash === $verify_password['password']){
                    header("location: ./logged_in.php");
                    echo "<div class='success'><p>Loging in</p></div>";
                }else{
                    echo "<div class='error'><p>Incorrect password</p></div>";
                }
        }else{
            echo "<div class='error'><p>Unknown email</p></div>";
        }
    }
?>