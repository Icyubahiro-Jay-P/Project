<?php
session_start();
include("connect.php");

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $hash = md5($password);

    $verify_email = mysqli_query($conn, "SELECT * FROM users WHERE email='{$email}'");
    if (mysqli_num_rows($verify_email) > 0) {
        $user = mysqli_fetch_assoc($verify_email);
        if (password_verify($hash, $user['password'])) {
            $_SESSION['email'] = $email;
            $_SESSION['success_message'] = "Logging in";
            header("Location: ./logged_in.php");
            exit();
        } else {
            $error_message = "Incorrect password";
        }
    } else {
        $error_message = "Unknown email";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Best Decor: Log In</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Best Decor</h1>
    <h3>Log in</h3>
    <?php
    if (isset($error_message)) {
        echo "<div class='error'><p>{$error_message}</p></div>";
    }
    ?>
    <form method="post">
        <div class="input-group">
            <input type="email" name="email" id="inputBox" placeholder="Email" required>
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Password" required>
            <span id="showPassword">Show</span>
        </div>
        <div class="input-group">
            <input type="submit" name="submit" value="Log in">
        </div>
        <p>No account? <a href="signup.php">Sign up</a></p>
    </form>
    <h4>&copy;Copyright 2024</h4>
    <script>
        // Your JavaScript code here
    </script>
</body>
</html>